#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 100

char* history[BUFFER_SIZE];
int history_count = 0;

int main(void) {
    close(2);
    dup(1);
    char command[BUFFER_SIZE];

    while (1) {
        fprintf(stdout, "my-shell> ");
        memset(command, 0, BUFFER_SIZE);
        if (fgets(command, BUFFER_SIZE, stdin) == NULL)
            break;

        command[strcspn(command, "\n")] = '\0'; 
        

        if (strncmp(command, "exit", 4) == 0) {
            break;
        }

        
        
            if (history_count < BUFFER_SIZE) {
                history[history_count] = (char*)malloc(strlen(command) + 1);
                if (history[history_count] == NULL) {
                    exit(1);
                }
                strcpy(history[history_count], command);
                history_count++;
            }
        

        if (strcmp(command, "history") == 0) {
            for (int j = history_count - 1; j >= 0; j--) {
                printf("%d %s\r\n", j + 1, history[j]);
            }
            continue;
        }

        if (strcmp(command, "clear_history") == 0) {
            for (int k = 0; k < history_count; k++) {
                free(history[k]);
                history[k] = NULL; // delete the pointer
            }
            
            history_count = 0;
            continue;        // We use 'continue' here because 'clear_history' is a built-in shell command,
                            // not an external program. Therefore, we handle it internally and skip the
                           // rest of the loop to avoid calling execvp() on it, which would result in an
                          // error like "exec failed: No such file or directory".

        }

        char* args[BUFFER_SIZE];   // Split the input command string into individual arguments (tokens),
                                  // using space as the delimiter, and store them in the args[] array.
        int i = 0;
        char* token = strtok(command, " ");
        while (token != NULL && i < BUFFER_SIZE - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;        // Null-terminate the args array to make it suitable for execvp().
                              // execvp expects the last element of the array to be NULL.

        int is_background = 0;  // Check if the command should be executed in the background.
                               // If the last argument is "&", we set is_background to true,
                              // and remove "&" from the args array so it's not passed to execvp
        if (i > 0 && strcmp(args[i - 1], "&") == 0) {
            is_background = 1;
            args[i - 1] = NULL;
        }

        pid_t pid = fork();
        if (pid == 0) {
            execvp(args[0], args);
         
            exit(1);
        }
        else if (pid > 0) {
            if (!is_background) {
                wait(NULL);
            }
        }
        
    }

    
    for (int k = 0; k < history_count; k++) {
        free(history[k]);
    }

    return 0;
}
